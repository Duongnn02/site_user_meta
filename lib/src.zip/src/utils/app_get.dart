import 'app_get_it.dart';

T findInstance<T extends Object>() {
  return getIt<T>();
}

